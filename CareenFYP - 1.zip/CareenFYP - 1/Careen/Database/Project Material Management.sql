--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md53175bce1d3201d16594cebf9d7eb3f9d';






--
-- Database creation
--

CREATE DATABASE "Project Material Management" WITH TEMPLATE = template0 OWNER = postgres;
REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


\connect -reuse-previous=on "dbname='Project Material Management'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Master Information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Master Information" (
    "ID" bigint NOT NULL,
    "Supplier Code" text,
    "Part Number" text,
    "Supplier Name" text,
    "MPN" text,
    "Lead Time" integer,
    "UpRev" text,
    "EOL" text,
    "LTB" text,
    "Risk Buy" text
);


ALTER TABLE public."Master Information" OWNER TO postgres;

--
-- Name: Master Information_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Master Information_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Master Information_ID_seq" OWNER TO postgres;

--
-- Name: Master Information_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Master Information_ID_seq" OWNED BY public."Master Information"."ID";


--
-- Name: Master Information 2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Master Information 2" (
    "ID" bigint DEFAULT nextval('public."Master Information_ID_seq"'::regclass) NOT NULL,
    "Supplier Code" text,
    "Part Number" text,
    "Supplier Name" text,
    "MPN" text,
    "Lead Time" integer,
    "UpRev" text,
    "EOL" text,
    "LTB" text,
    "Risk Buy" text
);


ALTER TABLE public."Master Information 2" OWNER TO postgres;

--
-- Name: Planner Supplier Information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Planner Supplier Information" (
    "ID" bigint NOT NULL,
    "Entry Date" date,
    "Planner" text,
    "Model" text,
    "Product Number" text,
    "Need Date" date,
    "Need Quantity" integer,
    "Supplier" text,
    "Supply Date" date,
    "Supply Quantity" integer
);


ALTER TABLE public."Planner Supplier Information" OWNER TO postgres;

--
-- Name: Planner Information_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Planner Information_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Planner Information_ID_seq" OWNER TO postgres;

--
-- Name: Planner Information_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Planner Information_ID_seq" OWNED BY public."Planner Supplier Information"."ID";


--
-- Name: Planner Supplier Information 2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Planner Supplier Information 2" (
    "ID" bigint DEFAULT nextval('public."Planner Information_ID_seq"'::regclass) NOT NULL,
    "Entry Date" date,
    "Planner" text,
    "Model" text,
    "Product Number" text,
    "Need Date" date,
    "Need Quantity" integer,
    "Supplier" text,
    "Supply Date" date,
    "Supply Quantity" integer
);


ALTER TABLE public."Planner Supplier Information 2" OWNER TO postgres;

--
-- Name: Reading Count; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Reading Count" (
    "Current Table" smallint NOT NULL
);


ALTER TABLE public."Reading Count" OWNER TO postgres;

--
-- Name: User Profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User Profile" (
    "Username" text NOT NULL,
    "Password" text,
    "Full Name" text
);


ALTER TABLE public."User Profile" OWNER TO postgres;

--
-- Name: Master Information ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Master Information" ALTER COLUMN "ID" SET DEFAULT nextval('public."Master Information_ID_seq"'::regclass);


--
-- Name: Planner Supplier Information ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Planner Supplier Information" ALTER COLUMN "ID" SET DEFAULT nextval('public."Planner Information_ID_seq"'::regclass);


--
-- Data for Name: Master Information; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Master Information" VALUES (1675827, '8161963_789297', 'MQKT000002A01', 'MBS SDN BHD', '12000002201', 20, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675828, '131660_805782', 'MQ8475653M01', 'TTK TECHNOLOGIES', '1023596', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675829, '131660_805782', 'MQ8475652M02', 'TTK TECHNOLOGIES', '1045215', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675830, '131660_805782', 'MQ8478060A01', 'TTK TECHNOLOGIES', '1045380', 40, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675831, '131660_805782', 'MQPC000150A01', 'TTK TECHNOLOGIES', '12000150201', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675832, '131660_805782', 'MQPC000150A02', 'TTK TECHNOLOGIES', '12000150202', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675833, '131660_805782', 'MQPC000332A01', 'TTK TECHNOLOGIES', '12000332201', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675834, '1099320_789225', 'MQPC000509A02', 'ATF LIMITED', '12000509202', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675835, '131660_805782', 'MQPC000683A01', 'TTK TECHNOLOGIES', '12000683201', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675836, '1099320_789225', 'MQPC000840A01', 'ATF LIMITED', '12000840201', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675837, '131660_805782', 'MQ84012131001', 'TTK TECHNOLOGIES', '84012131001', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675838, '131660_805782', 'MQ84012409002', 'TTK TECHNOLOGIES', '84012409002', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675839, '131660_805782', 'MQ84012443002', 'TTK TECHNOLOGIES', '84012443002', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675840, '131660_805782', 'MQ84012457001', 'TTK TECHNOLOGIES', '84012457001', 40, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675841, '0020968_788917', 'MVFR028630C', 'DSOQ', '220286303', 49, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675842, '131660_805782', 'MQ8475707M01', 'TTK TECHNOLOGIES', '1045216', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675843, '131660_805782', 'MQ8475712M01', 'TTK TECHNOLOGIES', '1045358', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675844, '131660_805782', 'MQ8475687M01', 'TTK TECHNOLOGIES', '1140930', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675845, '0020968_788917', 'MQPA002227A05', 'DSOQ', '2002505', 50, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675846, '1099320_789225', 'MQ8486250Z02', 'ATF LIMITED', '2002508', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675847, '1099320_789225', 'MQ8485908Z05', 'ATF LIMITED', '2009086', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675848, '8161963_789297', 'MQ0104046J26', 'MBS SDN BHD', '3534102', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675849, '8161963_789297', 'MQ0104046J25', 'MBS SDN BHD', '3534102', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675850, '0092213_788942', 'MQPC000176A02', 'UTECH CORP', '12000176202', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675851, '0054865_788932', 'MQPC001863A01', 'WPC', '12001863201', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675852, '0092213_788942', 'MQPC001915A01', 'UTECH CORP', '12001915201', 50, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675853, '0092213_788942', 'MQPC001918A01', 'UTECH CORP', '12001918201', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675854, '0092213_788942', 'MQPC001922A01', 'UTECH CORP', '12001922201', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675855, '0092213_788942', 'MQPC002012A01', 'UTECH CORP', '12002012201', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675856, '0020968_788917', 'MQ4064073H01', 'DSOQ', '12779', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675857, '0020968_788917', 'MQ0104034J95', 'DSOQ', '12851', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675858, '0020968_788917', 'MQPA002227A01', 'DSOQ', '13875', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675859, '8161963_789297', 'MQ84012231001', 'MBS SDN BHD', '152062', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675860, '8161963_789297', 'MQ0104046J13', 'MBS SDN BHD', '3550902', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675861, '8161963_789297', 'MQ8475744B01', 'MBS SDN BHD', '15208802', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675862, '8161963_789297', 'MQ8475744B05', 'MBS SDN BHD', '15208802', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675863, '8161963_789297', 'MQ0104046J24', 'MBS SDN BHD', '15210902', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675864, '8161963_789297', 'MQ0104046J27', 'MBS SDN BHD', '15212402', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675865, '0020968_788917', 'MVFR028530D', 'DSOQ', '220285303', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675866, '0020968_788917', 'MVFR028550C', 'DSOQ', '220285503', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675867, '8161963_789297', 'MQ0104065J53', 'MBS SDN BHD', '1104065153', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675868, '0092213_788942', 'MQ8485934F10', 'UTECH CORP', '8485934310', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675869, '75060_804342', 'MQPC000351A01', 'MELTEK', '12000351201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675870, '75060_804342', 'MQPC000353A01', 'MELTEK', '12000353201', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675871, '75060_804342', 'MQPC000354A01', 'MELTEK', '12000354201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675872, '75060_804342', 'MQPC000975A03', 'MELTEK', '12000975203', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675873, '75060_804342', 'MQPA001406A01', 'MELTEK', '12001406201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675874, '0054865_788932', 'MQPC001786A01', 'WPC', '12001786201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675875, '75060_804342', 'MQPC001820A01', 'MELTEK', '12001820201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675876, '0092213_788942', 'MQPC001964A01', 'UTECH CORP', '12001964201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675877, '0054865_788932', 'MQPC001979A01', 'WPC', '12001979201', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675878, '0054865_788932', 'MQPC002070A01', 'WPC', '12002070201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675879, '75060_804342', 'MQPC002091A01', 'MELTEK', '12002091201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675880, '75060_804342', 'MQPC002132A02', 'MELTEK', '12002132202', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675881, '0092213_788942', 'MQPC002252A01', 'UTECH CORP', '12002252201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675882, '0092213_788942', 'MQ84009304001', 'UTECH CORP', '84009304001', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675883, '75060_804342', 'MQ84009760001', 'MELTEK', '84009760001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675884, '75060_804342', 'MQ84012180003', 'MELTEK', '84012180003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675885, '75060_804342', 'MQ84012264002', 'MELTEK', '84012264002', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675886, '75060_804342', 'MQ84012275003', 'MELTEK', '84012275003', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675887, '0092213_788942', 'MQ84012382001', 'UTECH CORP', '84012382001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675888, '75060_804342', 'MQ84012404003', 'MELTEK', '84012404003', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675889, '75060_804342', 'MQ84012450001', 'MELTEK', '84012450001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675890, '0054865_788932', 'MQ84012504004', 'WPC', '84012504004', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675891, '0054865_788932', 'MQ84012505004', 'WPC', '84012505004', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675892, '0054865_788932', 'MQ84012591003', 'WPC', '84012591003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675893, '0054865_788932', 'MQ84012592003', 'WPC', '84012592003', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675894, '75060_804342', 'MQ84012619001', 'MELTEK', '84012619001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675895, '75060_804342', 'MQ84012716001', 'MELTEK', '84012716001', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675896, '75060_804342', 'MQ84012728003', 'MELTEK', '84012728003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675897, '75060_804342', 'MQ84012734002', 'MELTEK', '84012734002', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675898, '75060_804342', 'MQ84012735003', 'MELTEK', '84012735003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675899, '75060_804342', 'MQ84012736002', 'MELTEK', '84012736002', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675900, '0092213_788942', 'MQ8485325E02', 'UTECH CORP', '84853250020', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675901, '1099320_789225', 'MQ8486207B08', 'ATF LIMITED', '2002076', 65, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675902, '1099320_789225', 'MQ8485671Z05', 'ATF LIMITED', '2006718', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675903, '1099320_789225', 'MQ8486206B08', 'ATF LIMITED', '2002076007', 65, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675904, '0092213_788942', 'MQ8464191H02', 'UTECH CORP', '8464191302', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675905, '0092213_788942', 'MQ8475469B07', 'UTECH CORP', '8475469307', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675906, '0092213_788942', 'MQ8478167A02', 'UTECH CORP', '8478167202', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675907, '0092213_788942', 'MQPC001801A01', 'UTECH CORP', '12001801201', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675908, '0020968_788917', 'MQ8415637H01', 'DSOQ', '11804', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675909, '0020968_788917', 'MQPF001289A01', 'DSOQ', '13643', 70, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675910, '0020968_788917', 'MVFR028520B', 'DSOQ', '220285203', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675911, '0054865_788932', 'MQPC001404A02', 'WPC', '12001404202', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675912, '0054865_788932', 'MQPC001507A01', 'WPC', '12001507201', 70, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information" VALUES (1675913, '0054865_788932', 'MQPC001559A01', 'WPC', '12001559201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675914, '0054865_788932', 'MQPC001916A01', 'WPC', '12001916201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675915, '0054865_788932', 'MQPC001944A01', 'WPC', '12001944201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information" VALUES (1675916, '0054865_788932', 'MQPC001947A01', 'WPC', '12001947201', 70, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');


--
-- Data for Name: Master Information 2; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Master Information 2" VALUES (1675737, '8161963_789297', 'MQKT000002A01', 'MBS SDN BHD', '12000002201', 20, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675738, '131660_805782', 'MQ8475653M01', 'TTK TECHNOLOGIES', '1023596', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675739, '131660_805782', 'MQ8475652M02', 'TTK TECHNOLOGIES', '1045215', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675740, '131660_805782', 'MQ8478060A01', 'TTK TECHNOLOGIES', '1045380', 40, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675741, '131660_805782', 'MQPC000150A01', 'TTK TECHNOLOGIES', '12000150201', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675742, '131660_805782', 'MQPC000150A02', 'TTK TECHNOLOGIES', '12000150202', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675743, '131660_805782', 'MQPC000332A01', 'TTK TECHNOLOGIES', '12000332201', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675744, '1099320_789225', 'MQPC000509A02', 'ATF LIMITED', '12000509202', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675745, '131660_805782', 'MQPC000683A01', 'TTK TECHNOLOGIES', '12000683201', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675746, '1099320_789225', 'MQPC000840A01', 'ATF LIMITED', '12000840201', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675747, '131660_805782', 'MQ84012131001', 'TTK TECHNOLOGIES', '84012131001', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675748, '131660_805782', 'MQ84012409002', 'TTK TECHNOLOGIES', '84012409002', 40, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675749, '131660_805782', 'MQ84012443002', 'TTK TECHNOLOGIES', '84012443002', 40, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675750, '131660_805782', 'MQ84012457001', 'TTK TECHNOLOGIES', '84012457001', 40, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675751, '0020968_788917', 'MVFR028630C', 'DSOQ', '220286303', 49, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675752, '131660_805782', 'MQ8475707M01', 'TTK TECHNOLOGIES', '1045216', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675753, '131660_805782', 'MQ8475712M01', 'TTK TECHNOLOGIES', '1045358', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675754, '131660_805782', 'MQ8475687M01', 'TTK TECHNOLOGIES', '1140930', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675755, '0020968_788917', 'MQPA002227A05', 'DSOQ', '2002505', 50, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675756, '1099320_789225', 'MQ8486250Z02', 'ATF LIMITED', '2002508', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675757, '1099320_789225', 'MQ8485908Z05', 'ATF LIMITED', '2009086', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675758, '8161963_789297', 'MQ0104046J26', 'MBS SDN BHD', '3534102', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675759, '8161963_789297', 'MQ0104046J25', 'MBS SDN BHD', '3534102', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675760, '0092213_788942', 'MQPC000176A02', 'UTECH CORP', '12000176202', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675761, '0054865_788932', 'MQPC001863A01', 'WPC', '12001863201', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675762, '0092213_788942', 'MQPC001915A01', 'UTECH CORP', '12001915201', 50, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675763, '0092213_788942', 'MQPC001918A01', 'UTECH CORP', '12001918201', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675764, '0092213_788942', 'MQPC001922A01', 'UTECH CORP', '12001922201', 50, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675765, '0092213_788942', 'MQPC002012A01', 'UTECH CORP', '12002012201', 50, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675766, '0020968_788917', 'MQ4064073H01', 'DSOQ', '12779', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675767, '0020968_788917', 'MQ0104034J95', 'DSOQ', '12851', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675768, '0020968_788917', 'MQPA002227A01', 'DSOQ', '13875', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675769, '8161963_789297', 'MQ84012231001', 'MBS SDN BHD', '152062', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675770, '8161963_789297', 'MQ0104046J13', 'MBS SDN BHD', '3550902', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675771, '8161963_789297', 'MQ8475744B01', 'MBS SDN BHD', '15208802', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675772, '8161963_789297', 'MQ8475744B05', 'MBS SDN BHD', '15208802', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675773, '8161963_789297', 'MQ0104046J24', 'MBS SDN BHD', '15210902', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675774, '8161963_789297', 'MQ0104046J27', 'MBS SDN BHD', '15212402', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675775, '0020968_788917', 'MVFR028530D', 'DSOQ', '220285303', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675776, '0020968_788917', 'MVFR028550C', 'DSOQ', '220285503', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675777, '8161963_789297', 'MQ0104065J53', 'MBS SDN BHD', '1104065153', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675778, '0092213_788942', 'MQ8485934F10', 'UTECH CORP', '8485934310', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675779, '75060_804342', 'MQPC000351A01', 'MELTEK', '12000351201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675780, '75060_804342', 'MQPC000353A01', 'MELTEK', '12000353201', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675781, '75060_804342', 'MQPC000354A01', 'MELTEK', '12000354201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675782, '75060_804342', 'MQPC000975A03', 'MELTEK', '12000975203', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675783, '75060_804342', 'MQPA001406A01', 'MELTEK', '12001406201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675784, '0054865_788932', 'MQPC001786A01', 'WPC', '12001786201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675785, '75060_804342', 'MQPC001820A01', 'MELTEK', '12001820201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675786, '0092213_788942', 'MQPC001964A01', 'UTECH CORP', '12001964201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675787, '0054865_788932', 'MQPC001979A01', 'WPC', '12001979201', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675788, '0054865_788932', 'MQPC002070A01', 'WPC', '12002070201', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675789, '75060_804342', 'MQPC002091A01', 'MELTEK', '12002091201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675790, '75060_804342', 'MQPC002132A02', 'MELTEK', '12002132202', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675791, '0092213_788942', 'MQPC002252A01', 'UTECH CORP', '12002252201', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675792, '0092213_788942', 'MQ84009304001', 'UTECH CORP', '84009304001', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675793, '75060_804342', 'MQ84009760001', 'MELTEK', '84009760001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675794, '75060_804342', 'MQ84012180003', 'MELTEK', '84012180003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675795, '75060_804342', 'MQ84012264002', 'MELTEK', '84012264002', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675796, '75060_804342', 'MQ84012275003', 'MELTEK', '84012275003', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675797, '0092213_788942', 'MQ84012382001', 'UTECH CORP', '84012382001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675798, '75060_804342', 'MQ84012404003', 'MELTEK', '84012404003', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675799, '75060_804342', 'MQ84012450001', 'MELTEK', '84012450001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675800, '0054865_788932', 'MQ84012504004', 'WPC', '84012504004', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675801, '0054865_788932', 'MQ84012505004', 'WPC', '84012505004', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675802, '0054865_788932', 'MQ84012591003', 'WPC', '84012591003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675803, '0054865_788932', 'MQ84012592003', 'WPC', '84012592003', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675804, '75060_804342', 'MQ84012619001', 'MELTEK', '84012619001', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675805, '75060_804342', 'MQ84012716001', 'MELTEK', '84012716001', 60, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675806, '75060_804342', 'MQ84012728003', 'MELTEK', '84012728003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675807, '75060_804342', 'MQ84012734002', 'MELTEK', '84012734002', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675808, '75060_804342', 'MQ84012735003', 'MELTEK', '84012735003', 60, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675809, '75060_804342', 'MQ84012736002', 'MELTEK', '84012736002', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675810, '0092213_788942', 'MQ8485325E02', 'UTECH CORP', '84853250020', 60, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675811, '1099320_789225', 'MQ8486207B08', 'ATF LIMITED', '2002076', 65, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675812, '1099320_789225', 'MQ8485671Z05', 'ATF LIMITED', '2006718', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675813, '1099320_789225', 'MQ8486206B08', 'ATF LIMITED', '2002076007', 65, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675814, '0092213_788942', 'MQ8464191H02', 'UTECH CORP', '8464191302', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675815, '0092213_788942', 'MQ8475469B07', 'UTECH CORP', '8475469307', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675816, '0092213_788942', 'MQ8478167A02', 'UTECH CORP', '8478167202', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675817, '0092213_788942', 'MQPC001801A01', 'UTECH CORP', '12001801201', 65, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675818, '0020968_788917', 'MQ8415637H01', 'DSOQ', '11804', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675819, '0020968_788917', 'MQPF001289A01', 'DSOQ', '13643', 70, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675820, '0020968_788917', 'MVFR028520B', 'DSOQ', '220285203', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675821, '0054865_788932', 'MQPC001404A02', 'WPC', '12001404202', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675822, '0054865_788932', 'MQPC001507A01', 'WPC', '12001507201', 70, 'No Uprev', 'EOL', 'Yes LTB', 'Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675823, '0054865_788932', 'MQPC001559A01', 'WPC', '12001559201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675824, '0054865_788932', 'MQPC001916A01', 'WPC', '12001916201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675825, '0054865_788932', 'MQPC001944A01', 'WPC', '12001944201', 70, 'No Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');
INSERT INTO public."Master Information 2" VALUES (1675826, '0054865_788932', 'MQPC001947A01', 'WPC', '12001947201', 70, 'Uprev', 'Not EOL', 'No LTB', 'No Risk Buy');


--
-- Data for Name: Planner Supplier Information; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Planner Supplier Information" VALUES (327621, '2019-10-28', 'YC', 'APV850', 'MQ0104046J26', '2019-10-27', 123, 'MBS SDN BHD', '2019-11-10', 500);
INSERT INTO public."Planner Supplier Information" VALUES (327622, '2019-10-28', 'WS', 'Deilze ATTX', 'MQ84012736002', '2019-11-09', 442, 'MELTEK', '2019-11-09', 800);
INSERT INTO public."Planner Supplier Information" VALUES (327623, '2019-10-29', 'KY', 'Deilze ATTX', 'MQ8475744B01', '2019-10-27', 200, 'MBS SDN BHD', '2019-11-28', 500);
INSERT INTO public."Planner Supplier Information" VALUES (327624, '2019-10-29', 'KY', 'Deilze ATTX', 'MQ8486206B08', '2019-10-28', 100, 'ATF LIMITED', '2019-11-28', 100);
INSERT INTO public."Planner Supplier Information" VALUES (327625, '2019-10-29', 'Shamila', 'APV850', 'MQPC001786A01', '2019-11-09', 352, 'WPC', '2019-11-28', 600);
INSERT INTO public."Planner Supplier Information" VALUES (327626, '2019-10-29', 'YC', 'APV700', 'MQPC001947A01', '2019-11-13', 698, 'WPC', '2019-11-25', 800);
INSERT INTO public."Planner Supplier Information" VALUES (327627, '2019-10-29', 'Shamila', 'APV700', 'MQPC002091A01', '2019-11-09', 691, 'MELTEK', '2019-11-09', 800);
INSERT INTO public."Planner Supplier Information" VALUES (327628, '2019-10-29', 'WS', 'Deilze ATTX', 'MQPF001289A01', '2019-11-23', 493, 'DSOQ', '2019-11-25', 500);
INSERT INTO public."Planner Supplier Information" VALUES (327629, '2019-10-30', 'KY', 'Deilze ATTX', 'MQ84012591003', '2019-11-09', 64, 'WPC', '2019-12-22', 200);
INSERT INTO public."Planner Supplier Information" VALUES (327630, '2019-10-30', 'KY', 'Deilze ATTX', 'MQ84012734002', '2019-11-09', 511, 'MELTEK', '2019-12-22', 600);
INSERT INTO public."Planner Supplier Information" VALUES (327631, '2019-10-30', 'KY', 'APV700', 'MQ8475744B05', '2019-11-09', 197, 'MBS SDN BHD', '2019-11-14', 500);
INSERT INTO public."Planner Supplier Information" VALUES (327632, '2019-11-05', 'Shamila', 'Deilze ATTX', 'MQ84012716001', '2019-11-15', 50, 'MELTEK', '2019-12-20', 200);
INSERT INTO public."Planner Supplier Information" VALUES (327633, '2019-11-05', 'KY', 'APV700', 'MQ8486250Z02', '2019-12-05', 900, 'ATF LIMITED', '2019-12-24', 1000);
INSERT INTO public."Planner Supplier Information" VALUES (327634, '2019-11-05', 'WS', 'APV850', 'MQPA002227A01', '2019-12-16', 4800, 'DSOQ', '2019-12-22', 6000);
INSERT INTO public."Planner Supplier Information" VALUES (327635, '2019-11-05', 'WS', 'Deilze ATTX', 'MQ0104046J25', '2019-12-13', 542, 'MBS SDN BHD', '2019-12-29', 600);
INSERT INTO public."Planner Supplier Information" VALUES (327636, '2019-11-05', 'WS', 'APV850', 'MQPA002227A05', '2019-12-16', 2000, 'DSOQ', '2019-12-30', 1500);


--
-- Data for Name: Planner Supplier Information 2; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Planner Supplier Information 2" VALUES (327605, '2019-10-28', 'YC', 'APV850', 'MQ0104046J26', '2019-10-27', 123, 'MBS SDN BHD', '2019-11-10', 500);
INSERT INTO public."Planner Supplier Information 2" VALUES (327606, '2019-10-28', 'WS', 'Deilze ATTX', 'MQ84012736002', '2019-11-09', 442, 'MELTEK', '2019-11-09', 800);
INSERT INTO public."Planner Supplier Information 2" VALUES (327607, '2019-10-29', 'KY', 'Deilze ATTX', 'MQ8475744B01', '2019-10-27', 200, 'MBS SDN BHD', '2019-11-28', 500);
INSERT INTO public."Planner Supplier Information 2" VALUES (327608, '2019-10-29', 'KY', 'Deilze ATTX', 'MQ8486206B08', '2019-10-28', 100, 'ATF LIMITED', '2019-11-28', 100);
INSERT INTO public."Planner Supplier Information 2" VALUES (327609, '2019-10-29', 'Shamila', 'APV850', 'MQPC001786A01', '2019-11-09', 352, 'WPC', '2019-11-28', 600);
INSERT INTO public."Planner Supplier Information 2" VALUES (327610, '2019-10-29', 'YC', 'APV700', 'MQPC001947A01', '2019-11-13', 698, 'WPC', '2019-11-25', 800);
INSERT INTO public."Planner Supplier Information 2" VALUES (327611, '2019-10-29', 'Shamila', 'APV700', 'MQPC002091A01', '2019-11-09', 691, 'MELTEK', '2019-11-09', 800);
INSERT INTO public."Planner Supplier Information 2" VALUES (327612, '2019-10-29', 'WS', 'Deilze ATTX', 'MQPF001289A01', '2019-11-23', 493, 'DSOQ', '2019-11-25', 500);
INSERT INTO public."Planner Supplier Information 2" VALUES (327613, '2019-10-30', 'KY', 'Deilze ATTX', 'MQ84012591003', '2019-11-09', 64, 'WPC', '2019-12-22', 200);
INSERT INTO public."Planner Supplier Information 2" VALUES (327614, '2019-10-30', 'KY', 'Deilze ATTX', 'MQ84012734002', '2019-11-09', 511, 'MELTEK', '2019-12-22', 600);
INSERT INTO public."Planner Supplier Information 2" VALUES (327615, '2019-10-30', 'KY', 'APV700', 'MQ8475744B05', '2019-11-09', 197, 'MBS SDN BHD', '2019-11-14', 500);
INSERT INTO public."Planner Supplier Information 2" VALUES (327616, '2019-11-05', 'Shamila', 'Deilze ATTX', 'MQ84012716001', '2019-11-15', 50, 'MELTEK', '2019-12-20', 200);
INSERT INTO public."Planner Supplier Information 2" VALUES (327617, '2019-11-05', 'KY', 'APV700', 'MQ8486250Z02', '2019-12-05', 900, 'ATF LIMITED', '2019-12-24', 1000);
INSERT INTO public."Planner Supplier Information 2" VALUES (327618, '2019-11-05', 'WS', 'APV850', 'MQPA002227A01', '2019-12-16', 4800, 'DSOQ', '2019-12-22', 6000);
INSERT INTO public."Planner Supplier Information 2" VALUES (327619, '2019-11-05', 'WS', 'Deilze ATTX', 'MQ0104046J25', '2019-12-13', 542, 'MBS SDN BHD', '2019-12-29', 600);
INSERT INTO public."Planner Supplier Information 2" VALUES (327620, '2019-11-05', 'WS', 'APV850', 'MQPA002227A05', '2019-12-16', 2000, 'DSOQ', '2019-12-30', 1500);


--
-- Data for Name: Reading Count; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Reading Count" VALUES (1);


--
-- Data for Name: User Profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."User Profile" VALUES ('careen', 'abc123', 'Careen Khor');


--
-- Name: Master Information_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Master Information_ID_seq"', 1675916, true);


--
-- Name: Planner Information_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Planner Information_ID_seq"', 327636, true);


--
-- Name: Master Information 2 Master Information 2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Master Information 2"
    ADD CONSTRAINT "Master Information 2_pkey" PRIMARY KEY ("ID");


--
-- Name: Master Information Master Information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Master Information"
    ADD CONSTRAINT "Master Information_pkey" PRIMARY KEY ("ID");


--
-- Name: Planner Supplier Information Planner Information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Planner Supplier Information"
    ADD CONSTRAINT "Planner Information_pkey" PRIMARY KEY ("ID");


--
-- Name: Planner Supplier Information 2 Planner Supplier Information 2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Planner Supplier Information 2"
    ADD CONSTRAINT "Planner Supplier Information 2_pkey" PRIMARY KEY ("ID");


--
-- Name: Reading Count Reading Count_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reading Count"
    ADD CONSTRAINT "Reading Count_pkey" PRIMARY KEY ("Current Table");


--
-- Name: User Profile User Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User Profile"
    ADD CONSTRAINT "User Profile_pkey" PRIMARY KEY ("Username");


--
-- PostgreSQL database dump complete
--

\connect postgres

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

\connect template1

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

