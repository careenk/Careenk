<?php
    function OpenDatabase()
    {
        $dbhost = 'localhost';
        $dbname = 'Project Material Management';
        $dbuser = 'postgres';
        $dbpass = 'postgres';

        // open a connection to the database server
        $connection = pg_pconnect ( "host='$dbhost' dbname='$dbname' user='$dbuser' password='$dbpass'" );

        if ( !$connection )
        {
            die ( "Could not open connection to database server!" );
        }

        return $connection;
    }

    function QueryDatabase ( $connection, $query )
    {
        $result = pg_query ( $connection, $query ) or die ( "Error in query: '$query' (" . pg_last_error ( $connection ) . ')' );

        return $result;
    }

    function GetNumRows ( $result )
    {
        return pg_numrows ( $result );
    }

    function ReadField ( $result, $row, $field )
    {
        return pg_result ( $result, $row, '"' . $field . '"' );
    }

    function CloseDatabase ( $connection )
    {
        pg_close ( $connection );
    }
?>
