<table width='100%' border='1'>
<tr>
	<th>No</th>
    <th>Model</th>
    <th>Product Number</th>
    <th>Planner Date</th>
    <th>Planner Quantity</th>
</tr>
<?php
	$week = $_POST['week'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';
	$masterTable = 'Master Information';

	if ( $currentReadTable != 1 )
	{
		$plannerSupplierTable .= " $currentReadTable";
		$masterTable .= " $currentReadTable";
	}

	if ( $week !== '' )
	{
		$sql = 'SELECT "Model","Product Number","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
		   "to_char(\"Entry Date\",'WW YYYY')='$week' AND (\"Need Date\" <= (CURRENT_DATE + INTERVAL '3 days') AND \"Need Date\">CURRENT_DATE) " .
		   'ORDER BY "Need Date" ASC,"Model" ASC,"Product Number" ASC';
	}
	else
	{
		$sql = 'SELECT "Model","Product Number","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
		   "\"Need Date\" <= (CURRENT_DATE + INTERVAL '3 days') AND \"Need Date\">CURRENT_DATE " .
		   'ORDER BY "Need Date" ASC,"Model" ASC,"Product Number" ASC';
	}

	$result = QueryDatabase ( $connection, $sql );

	$numItems = GetNumRows ( $result );

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$model = ReadField ( $result, $itemIndex, 'Model' );
		$productNumber = ReadField ( $result, $itemIndex, 'Product Number' );
		$needDate = ReadField ( $result, $itemIndex, 'Need Date' );
		$needQuantity = ReadField ( $result, $itemIndex, 'Need Quantity' );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$model</td>\n";
		echo "    <td>$productNumber</td>\n";
		echo "    <td>$needDate</td>\n";
		echo "    <td>$needQuantity</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table>