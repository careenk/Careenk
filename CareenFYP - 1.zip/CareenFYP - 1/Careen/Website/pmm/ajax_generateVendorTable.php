<table width='100%' border='1'>
<tr>
	<th>No</th>
    <th>Supplier</th>
    <th>Model</th>
    <th>Product Number</th>
    <th>Planner</th>
    <th>Supply Date</th>
    <th>Supply Quantity</th>
</tr>
<?php
	$week = $_POST['week'];
	$vendor = $_POST['vendor'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';

	if ( $currentReadTable != 1 )
		$plannerSupplierTable .= " $currentReadTable";

	if ( $week !== '' )
	{
		if ( $vendor !== '' )
		{
			$sql = 'SELECT "Supplier","Model","Product Number","Planner","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "to_char(\"Entry Date\",'WW YYYY')='$week' AND \"Supplier\"='$vendor' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
		}
		else
		{
			$sql = 'SELECT "Supplier","Model","Product Number","Planner","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "to_char(\"Entry Date\",'WW YYYY')='$week' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
		}
	}
	else if ( $vendor !== '' )
	{
			$sql = 'SELECT "Supplier","Model","Product Number","Planner","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "\"Supplier\"='$vendor' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}
	else
	{
			$sql = 'SELECT "Supplier","Model","Product Number","Planner","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" ' .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}

	$result = QueryDatabase ( $connection, $sql );

	$numItems = GetNumRows ( $result );

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$supplier = ReadField ( $result, $itemIndex, 'Supplier' );
		$model = ReadField ( $result, $itemIndex, 'Model' );
		$productNumber = ReadField ( $result, $itemIndex, 'Product Number' );
		$planner = ReadField ( $result, $itemIndex, 'Planner' );
		$supplyDate = ReadField ( $result, $itemIndex, 'Supply Date' );
		$supplyQuantity = ReadField ( $result, $itemIndex, 'Supply Quantity' );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$supplier</td>\n";
		echo "    <td>$model</td>\n";
		echo "    <td>$productNumber</td>\n";
		echo "    <td>$planner</td>\n";
		echo "    <td>$supplyDate</td>\n";
		echo "    <td>$supplyQuantity</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table>