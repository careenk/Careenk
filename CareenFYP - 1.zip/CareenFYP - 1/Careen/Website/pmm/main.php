<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<br /><input type='button' value='Planner' class='buttons' onclick='location.href="planner.php"' /><br />
<br /><input type='button' value='Vendor' class='buttons' onclick='location.href="vendor.php"' /><br />
<br /><input type='button' value='Control' class='buttons' onclick='location.href="control.php"' /><br />
<br /><input type='button' value='Settings' class='buttons' onclick='location.href="settings.php"' /><br />
<br /><input type='button' value='Reminders' class='buttons' onclick='location.href="reminders.php"' /><br />
<br /><br /><br /><br /><input type='button' value='Logout' class='buttons' onclick='location.href="logout.php"' /><br />
<?php require ( 'footer.php' ); ?>