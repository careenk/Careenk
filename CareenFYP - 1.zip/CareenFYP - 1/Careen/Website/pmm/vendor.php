<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function Generate()
{
	var weekEl = document.getElementById('week')
	var week = weekEl.options [ weekEl.selectedIndex ].value

	var vendorEl = document.getElementById('vendor')
	var vendor = vendorEl.options [ vendorEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			document.getElementById('spanVendorTable').innerHTML = this.responseText
        }
    }

    xmlhttp.open ( 'POST', 'ajax_generateVendorTable.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'week=' + week + '&vendor=' + vendor )
}

function HandleWeekChanged()
{
	var weekEl = document.getElementById('week')
	var week = weekEl.options [ weekEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			document.getElementById('spanVendorDropdown').innerHTML = this.responseText
        }
    }

    xmlhttp.open ( 'POST', 'ajax_generateVendorDropdown.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'week=' + week )
}
</script>
<br /></center>
<table width='30%'>
<tr>
	<td width='40%'>Week:</td>
    <td width='60%'><select id='week' class='textInputs' required='required' onchange='HandleWeekChanged()'>
    <option value=''>All</option>
    <?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';

	if ( $currentReadTable != 1 )
		$plannerSupplierTable .= " $currentReadTable";

	$result = QueryDatabase ( $connection, 'SELECT DISTINCT to_char("Entry Date",\'WW\') AS "Week",to_char("Entry Date",\'YYYY\') AS "Year" FROM "' . $plannerSupplierTable . '" ORDER BY "Year" DESC,"Week" DESC' );

	$numWeeks = GetNumRows ( $result );

	for ( $weekIndex = 0; $weekIndex < $numWeeks; ++$weekIndex )
	{
		$week = ReadField ( $result, $weekIndex, 'Week' );
		$year = ReadField ( $result, $weekIndex, 'Year' );
		echo "<option value='$week $year'>WW$week $year</option>\n";
	}
	?>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Vendor:</td>
    <td><span id='spanVendorDropdown'><select id='vendor' class='textInputs' required='required'>
    <option value=''>All</option>
	<?php
	$result = QueryDatabase ( $connection, 'SELECT DISTINCT "Supplier" FROM "' . $plannerSupplierTable . '" ORDER BY "Supplier" ASC' );

	$numVendors = GetNumRows ( $result );

	for ( $vendorIndex = 0; $vendorIndex < $numVendors; ++$vendorIndex )
	{
		$supplier = ReadField ( $result, $vendorIndex, 'Supplier' );
		echo "<option value='$supplier'>$supplier</option>\n";
	}

	CloseDatabase ( $connection );
	?>
    </select></span></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td colspan='2'><input type='button' value='Generate' class='buttons' style='width:150px;height:30px' onclick='Generate()' />&nbsp;<input type='button' value='Back' class='buttons' style='width:150px;height:30px' onclick='history.go(-1)' /></td>
</tr>
</table>
<center>
<br /><span id='spanVendorTable'></span>
<?php require ( 'footer.php' ); ?>