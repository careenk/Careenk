<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
</center>
<table width='100%'>
<tr>
	<td width='10%'>&nbsp;</td>
	<td width='80%'><center><h3>Settings</h3></center></td>
    <td width='10%'><input type='button' value='Back' class='buttons' style='width:150px;height:30px' onclick='history.go(-1)' /></td>
</tr>
</table>
<center>
<br /><table width='100%' border='1'>
<tr>
	<th>No</th>
    <th>Model</th>
    <th>Product Number</th>
    <th>UpRev</th>
    <th>EOL</th>
    <th>LTB</th>
    <th>Risk Buy</th>
</tr>
<?php
require_once ( 'database.php' );

$connection = OpenDatabase();

$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
$currentReadTable = ReadField ( $result, 0, 'Current Table' );

$masterTable = 'Master Information';

if ( $currentReadTable != 1 )
	$masterTable .= " $currentReadTable";

$result = QueryDatabase ( $connection, 'SELECT "MPN","Part Number","UpRev","EOL","LTB","Risk Buy" FROM "' . $masterTable . '" ORDER BY "MPN" ASC,"Part Number" ASC' );

$numItems = GetNumRows ( $result );

for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
{
	$no = $itemIndex + 1;
	$mpn = ReadField ( $result, $itemIndex, 'MPN' );
	$partNumber = ReadField ( $result, $itemIndex, 'Part Number' );
	$upRev = ReadField ( $result, $itemIndex, 'UpRev' );
	$eol = ReadField ( $result, $itemIndex, 'EOL' );
	$ltb = ReadField ( $result, $itemIndex, 'LTB' );
	$riskBuy = ReadField ( $result, $itemIndex, 'Risk Buy' );

	echo "<tr align='center'>\n";
	echo "    <td>$no</td>\n";
	echo "    <td>$mpn</td>\n";
	echo "    <td>$partNumber</td>\n";
	echo "    <td>$upRev</td>\n";
	echo "    <td>$eol</td>\n";
	echo "    <td>$ltb</td>\n";
	echo "    <td>$riskBuy</td>\n";
	echo "</tr>\n";
}

CloseDatabase ( $connection );
?>
</table>
<?php require ( 'footer.php' ); ?>