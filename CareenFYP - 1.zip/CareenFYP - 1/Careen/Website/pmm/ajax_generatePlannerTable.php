<table width='100%' border='1'>
<tr>
	<th>No</th>
    <th>Planner</th>
    <th>Model</th>
    <th>Product Number</th>
    <th>Supplier</th>
    <th>Need Date</th>
    <th>Need Quantity</th>
</tr>
<?php
	$week = $_POST['week'];
	$planner = $_POST['planner'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';

	if ( $currentReadTable != 1 )
		$plannerSupplierTable .= " $currentReadTable";

	if ( $week !== '' )
	{
		if ( $planner !== '' )
		{
			$sql = 'SELECT "Planner","Model","Product Number","Supplier","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "to_char(\"Entry Date\",'WW YYYY')='$week' AND \"Planner\"='$planner' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
		}
		else
		{
			$sql = 'SELECT "Planner","Model","Product Number","Supplier","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "to_char(\"Entry Date\",'WW YYYY')='$week' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
		}
	}
	else if ( $planner !== '' )
	{
			$sql = 'SELECT "Planner","Model","Product Number","Supplier","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
			   "\"Planner\"='$planner' " .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}
	else
	{
			$sql = 'SELECT "Planner","Model","Product Number","Supplier","Need Date","Need Quantity" FROM "' . $plannerSupplierTable . '" ' .
			   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}

	$result = QueryDatabase ( $connection, $sql );

	$numItems = GetNumRows ( $result );

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$planner = ReadField ( $result, $itemIndex, 'Planner' );
		$model = ReadField ( $result, $itemIndex, 'Model' );
		$productNumber = ReadField ( $result, $itemIndex, 'Product Number' );
		$supplier = ReadField ( $result, $itemIndex, 'Supplier' );
		$needDate = ReadField ( $result, $itemIndex, 'Need Date' );
		$needQuantity = ReadField ( $result, $itemIndex, 'Need Quantity' );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$planner</td>\n";
		echo "    <td>$model</td>\n";
		echo "    <td>$productNumber</td>\n";
		echo "    <td>$supplier</td>\n";
		echo "    <td>$needDate</td>\n";
		echo "    <td>$needQuantity</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table>