<?php
	session_start();

	$username = $_POST['username'];
	$password = $_POST['password'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Full Name" FROM "User Profile" WHERE "Username"=' . "'$username' AND \"Password\"='$password'" );

	if ( GetNumRows ( $result ) != 1 )
	{
		CloseDatabase ( $connection );
		die ( 'Invalid' );
	}

	$_SESSION['username'] = $username;
	$_SESSION['fullName'] = ReadField ( $result, 0, 'Full Name' );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
