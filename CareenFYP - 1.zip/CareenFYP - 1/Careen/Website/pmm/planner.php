<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function Generate()
{
	var weekEl = document.getElementById('week')
	var week = weekEl.options [ weekEl.selectedIndex ].value

	var plannerEl = document.getElementById('planner')
	var planner = plannerEl.options [ plannerEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			document.getElementById('spanPlannerTable').innerHTML = this.responseText
        }
    }

    xmlhttp.open ( 'POST', 'ajax_generatePlannerTable.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'week=' + week + '&planner=' + planner )
}

function HandleWeekChanged()
{
	var weekEl = document.getElementById('week')
	var week = weekEl.options [ weekEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			document.getElementById('spanPlannerDropdown').innerHTML = this.responseText
        }
    }

    xmlhttp.open ( 'POST', 'ajax_generatePlannerDropdown.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'week=' + week )
}
</script>
<br /></center>
<table width='30%'>
<tr>
	<td width='40%'>Week:</td>
    <td width='60%'><select id='week' class='textInputs' required='required' onchange='HandleWeekChanged()'>
    <option value=''>All</option>
    <?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';

	if ( $currentReadTable != 1 )
		$plannerSupplierTable .= " $currentReadTable";

	$result = QueryDatabase ( $connection, 'SELECT DISTINCT to_char("Entry Date",\'WW\') AS "Week",to_char("Entry Date",\'YYYY\') AS "Year" FROM "' . $plannerSupplierTable . '" ORDER BY "Year" DESC,"Week" DESC' );

	$numWeeks = GetNumRows ( $result );

	for ( $weekIndex = 0; $weekIndex < $numWeeks; ++$weekIndex )
	{
		$week = ReadField ( $result, $weekIndex, 'Week' );
		$year = ReadField ( $result, $weekIndex, 'Year' );
		echo "<option value='$week $year'>WW$week $year</option>\n";
	}
	?>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Planner:</td>
    <td><span id='spanPlannerDropdown'><select id='planner' class='textInputs' required='required'>
    <option value=''>All</option>
	<?php
	$result = QueryDatabase ( $connection, 'SELECT DISTINCT "Planner" FROM "' . $plannerSupplierTable . '" ORDER BY "Planner" ASC' );

	$numPlanners = GetNumRows ( $result );

	for ( $plannerIndex = 0; $plannerIndex < $numPlanners; ++$plannerIndex )
	{
		$planner = ReadField ( $result, $plannerIndex, 'Planner' );
		echo "<option value='$planner'>$planner</option>\n";
	}

	CloseDatabase ( $connection );
	?>
    </select></span></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td colspan='2'><input type='button' value='Generate' class='buttons' style='width:150px;height:30px' onclick='Generate()' />&nbsp;<input type='button' value='Back' class='buttons' style='width:150px;height:30px' onclick='history.go(-1)' /></td>
</tr>
</table>
<center>
<br /><span id='spanPlannerTable'></span>
<?php require ( 'footer.php' ); ?>