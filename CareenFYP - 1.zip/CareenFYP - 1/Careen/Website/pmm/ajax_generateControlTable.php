<table width='100%' border='1'>
<tr>
	<th>No</th>
    <th>Model</th>
    <th>Product Number</th>
    <th>Planner Date</th>
    <th>Planner Quantity</th>
    <th>Supply Date</th>
    <th>Supply Quantity</th>
    <th>Lead Time</th>
    <th>SLT Comment</th>
</tr>
<?php
	$week = $_POST['week'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';
	$masterTable = 'Master Information';

	if ( $currentReadTable != 1 )
	{
		$plannerSupplierTable .= " $currentReadTable";
		$masterTable .= " $currentReadTable";
	}

	if ( $week !== '' )
	{
		$sql = 'SELECT "ID","Model","Product Number","Need Date","Need Quantity","Supplier","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" WHERE ' .
		   "to_char(\"Entry Date\",'WW YYYY')='$week' " .
		   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}
	else
	{
		$sql = 'SELECT "ID","Model","Product Number","Need Date","Need Quantity","Supplier","Supply Date","Supply Quantity" FROM "' . $plannerSupplierTable . '" ' .
		   'ORDER BY "Entry Date" ASC,"Model" ASC,"Product Number" ASC';
	}

	$result = QueryDatabase ( $connection, $sql );

	$numItems = GetNumRows ( $result );

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$id = ReadField ( $result, $itemIndex, 'ID' );
		$model = ReadField ( $result, $itemIndex, 'Model' );
		$productNumber = ReadField ( $result, $itemIndex, 'Product Number' );
		$needDate = ReadField ( $result, $itemIndex, 'Need Date' );
		$needQuantity = ReadField ( $result, $itemIndex, 'Need Quantity' );
		$supplier = ReadField ( $result, $itemIndex, 'Supplier' );
		$supplyDate = ReadField ( $result, $itemIndex, 'Supply Date' );
		$supplyQuantity = ReadField ( $result, $itemIndex, 'Supply Quantity' );

		$result2 = QueryDatabase ( $connection, 'SELECT "Lead Time" FROM "' . $masterTable . '" WHERE "Supplier Name"=' . "'$supplier' AND \"Part Number\"='$productNumber'" );

		$leadTime = ( GetNumRows ( $result2 ) == 1 ) ? ReadField ( $result2, 0, 'Lead Time' ) : 'N/A';

		$result2 = QueryDatabase ( $connection, "SELECT \"Supply Date\">(CURRENT_DATE+INTERVAL '$leadTime days') AS \"Condition 1\",\"Need Date\"<\"Supply Date\" AS \"Condition 2\" FROM \"$plannerSupplierTable\" WHERE \"ID\"=$id" );

		$condition1 = ReadField ( $result2, 0, 'Condition 1' );
		$condition2 = ReadField ( $result2, 0, 'Condition 2' );

		if ( $condition1 === 't' )
			$sltComment = 'Alert buyer check with supplier';
		else if ( $condition2 === 't' )
			$sltComment = 'SLT';
		else
			$sltComment = 'OK';

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$model</td>\n";
		echo "    <td>$productNumber</td>\n";
		echo "    <td>$needDate</td>\n";
		echo "    <td>$needQuantity</td>\n";
		echo "    <td>$supplyDate</td>\n";
		echo "    <td>$supplyQuantity</td>\n";
		echo "    <td>$leadTime</td>\n";
		echo "    <td>$sltComment</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table>