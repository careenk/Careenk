<select id='vendor' class='textInputs' required='required'>
<option value=''>All</option>
<?php
	$week = $_POST['week'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Current Table" FROM "Reading Count"' );	
	$currentReadTable = ReadField ( $result, 0, 'Current Table' );

	$plannerSupplierTable = 'Planner Supplier Information';

	if ( $currentReadTable != 1 )
		$plannerSupplierTable .= " $currentReadTable";

	if ( $week !== '' )
		$result = QueryDatabase ( $connection, 'SELECT DISTINCT "Supplier" FROM "' . $plannerSupplierTable . '" WHERE to_char("Entry Date",\'WW YYYY\')=' . "'$week'" . ' ORDER BY "Supplier" ASC' );
	else
		$result = QueryDatabase ( $connection, 'SELECT DISTINCT "Supplier" FROM "' . $plannerSupplierTable . '" ORDER BY "Supplier" ASC' );

	$numVendors = GetNumRows ( $result );

	for ( $vendorIndex = 0; $vendorIndex < $numVendors; ++$vendorIndex )
	{
		$supplier = ReadField ( $result, $vendorIndex, 'Supplier' );
		echo "<option value='$supplier'>$supplier</option>\n";
	}

	CloseDatabase ( $connection );
?>
</select>