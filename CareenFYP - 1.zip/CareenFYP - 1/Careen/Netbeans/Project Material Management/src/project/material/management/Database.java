package project.material.management;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import org.postgresql.jdbc.PgConnection;
import org.postgresql.largeobject.LargeObject;
import org.postgresql.largeobject.LargeObjectManager;

public class Database
{
    private static PgConnection connection = null;

    private final static int dbPort = 5432;
    private final static String dbName = "Project Material Management";
    private final static String dbUsername = "postgres";
    private final static String dbPassword = "postgres";

    public static String connStr = "jdbc:postgresql://localhost:" + dbPort + "/" + dbName + "?user=" + dbUsername + "&password=" + dbPassword;

    public static void UpdateConnectionString (String serverAddress)
    {
        connStr = "jdbc:postgresql://" + serverAddress + ":" + dbPort + "/" + dbName + "?user=" + dbUsername + "&password=" + dbPassword;
    }

    public static void InitDatabase()
    {
        try
        {
            Class.forName("org.postgresql.Driver");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    public static void OpenDatabase() throws SQLException
    {
        CloseDatabase();

        DriverManager.setLoginTimeout(100);
        connection = (PgConnection)DriverManager.getConnection(connStr);

        connection.setAutoCommit(false);
    }

    public static PreparedStatement GetPreparedStatement(String sql) throws SQLException
    {
        return connection.prepareStatement(sql);
    }

    public static long NonQueryDatabase(PreparedStatement ps) throws SQLException
    {
        long newID = -1;

        ResultSet rs = null;

        SQLException sqlException = null;

        try
        {
            rs = ps.executeQuery();

            rs.next();

            newID = rs.getLong(1);
        }
        catch ( SQLException e )
        {
            sqlException = e;
        }
        finally
        {
            try
            {
                if ( rs != null ) rs.close();
            }
            catch ( SQLException e )
            {}

            try
            {
                if ( ps != null ) ps.close();
            }
            catch ( SQLException e )
            {}
        }

        if (sqlException != null)
            throw sqlException;

        return newID;
    }

    public static void Commit() throws SQLException
    {
        connection.commit();
    }

    public static void UnlinkLargeObject(long oid) throws SQLException, IOException
    {
        LargeObjectManager lobj = connection.getLargeObjectAPI();

        lobj.unlink(oid);
    }

    public static long WriteLargeObject(InputStream inputStream) throws SQLException, IOException
    {
        LargeObjectManager lobj = connection.getLargeObjectAPI();

        long oid = lobj.createLO(LargeObjectManager.READ | LargeObjectManager.WRITE);

        LargeObject obj = lobj.open(oid, LargeObjectManager.WRITE);

        byte buf[] = new byte[2048];
        int data;

        while ( ( data = inputStream.read ( buf, 0, 2048 ) ) > 0 )
            obj.write(buf, 0, data);

        obj.close();

        return oid;
    }

    public static BufferedImage LoadImage ( long oid ) throws SQLException, IOException
    {
        LargeObjectManager lobj = connection.getLargeObjectAPI();

        LargeObject objPicture = lobj.open ( oid, LargeObjectManager.READ );
        
        byte[] bufPicture = new byte[objPicture.size()];
        objPicture.read ( bufPicture, 0, objPicture.size() );
        objPicture.close();
        
        BufferedImage bImage = ImageIO.read(new ByteArrayInputStream(bufPicture));

        return bImage;
    }

    public static void CloseDatabase() throws SQLException
    {
        if (connection != null)
        {
            connection.close();
            connection = null;
        }
    }
}
