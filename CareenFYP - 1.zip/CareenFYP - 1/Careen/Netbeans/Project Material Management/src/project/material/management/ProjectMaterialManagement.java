package project.material.management;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ProjectMaterialManagement
{
    private final static String excelPath = "C:\\Bitnami\\wappstack-7.1.29-0\\apache2\\htdocs\\pmm\\excel\\";

    private final static String plannerSupplierPath = excelPath + "planner.xlsx";
    private final static String masterPath = excelPath + "master.xlsx";

    private final static ArrayList<Date> alEntryDate = new ArrayList<>();
    private final static ArrayList<String> alPlanner = new ArrayList<>();
    private final static ArrayList<String> alModel = new ArrayList<>();
    private final static ArrayList<String> alProductNumber = new ArrayList<>();
    private final static ArrayList<Date> alNeedDate = new ArrayList<>();
    private final static ArrayList<Integer> alNeedQuantity = new ArrayList<>();
    private final static ArrayList<String> alSupplier = new ArrayList<>();
    private final static ArrayList<Date> alSupplyDate = new ArrayList<>();
    private final static ArrayList<Integer> alSupplyQuantity = new ArrayList<>();

    private final static ArrayList<String> alMasterSupplierCode = new ArrayList<>();
    private final static ArrayList<String> alMasterPartNumber = new ArrayList<>();
    private final static ArrayList<String> alMasterSupplierName = new ArrayList<>();
    private final static ArrayList<String> alMasterMPN = new ArrayList<>();
    private final static ArrayList<Integer> alMasterLeadTime = new ArrayList<>();
    private final static ArrayList<String> alMasterUpRev = new ArrayList<>();
    private final static ArrayList<String> alMasterEOL= new ArrayList<>();
    private final static ArrayList<String> alMasterLTB = new ArrayList<>();
    private final static ArrayList<String> alMasterRiskBuy = new ArrayList<>();

    private static int GetCurrentWriteTable()
    {
        String sql = "SELECT \"Current Table\" FROM \"Reading Count\"";

        PreparedStatement ps = null;
        ResultSet rs = null;

        int currentTable = 2;
        boolean isSuccess = true;

        try
        {
            ps = Database.GetPreparedStatement ( sql );
            rs = ps.executeQuery();

            if (rs.next())
            {
                currentTable = 3 - rs.getInt ( 1 );
            }
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error reading current read table from PostgreSQL database: " + e.getMessage(), "Error retrieving current read table!", JOptionPane.ERROR_MESSAGE);
            isSuccess = false;
        }
        finally
        {
            try
            {
                if (rs != null) rs.close();
            }
            catch (SQLException e)
            {}

            try
            {
                if (ps != null) ps.close();
            }
            catch (SQLException e)
            {}
        }
        
        return isSuccess ? currentTable : 0;
    }

    private static boolean ReadPlannerSupplierExcelFile()
    {
        FileInputStream excelFile = null;
        Workbook workbook = null;
        Sheet datatypeSheet = null;

        try
        {
            excelFile = new FileInputStream(new File(plannerSupplierPath));
            workbook = new XSSFWorkbook(excelFile);
            datatypeSheet = workbook.getSheetAt(0);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return false;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return false;
        }

        int row = 3;

        alEntryDate.clear();
        alPlanner.clear();
        alModel.clear();
        alProductNumber.clear();
        alNeedDate.clear();
        alNeedQuantity.clear();
        alSupplier.clear();
        alSupplyDate.clear();
        alSupplyQuantity.clear();

        Date entryDate, needDate, supplyDate;
        String planner, model, productNumber, supplier;
        int needQuantity, supplyQuantity;

        while (true)
        {
            try
            {
                Cell cell = datatypeSheet.getRow(row).getCell(0);
                if (HSSFDateUtil.isCellDateFormatted(cell))
                    entryDate = cell.getDateCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(1);
                if (cell.getCellType() == CellType.STRING)
                    planner = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(2);
                if (cell.getCellType() == CellType.STRING)
                    model = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(3);
                if (cell.getCellType() == CellType.STRING)
                    productNumber = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(4);
                if (cell.getCellType() == CellType.NUMERIC)
                    needQuantity = (int)Math.round(cell.getNumericCellValue());
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(5);
                if (HSSFDateUtil.isCellDateFormatted(cell))
                    needDate = cell.getDateCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(12);
                if (cell.getCellType() == CellType.STRING)
                    supplier = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(13);
                if (cell.getCellType() == CellType.NUMERIC)
                    supplyQuantity = (int)Math.round(cell.getNumericCellValue());
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(14);
                if (HSSFDateUtil.isCellDateFormatted(cell))
                    supplyDate = cell.getDateCellValue();
                else
                    continue;

                ++row;
                
                alEntryDate.add(entryDate);
                alPlanner.add(planner);
                alModel.add(model);
                alProductNumber.add(productNumber);
                alNeedDate.add(needDate);
                alNeedQuantity.add(needQuantity);
                alSupplier.add(supplier);
                alSupplyDate.add(supplyDate);
                alSupplyQuantity.add(supplyQuantity);
            }
            catch (NullPointerException e)
            {
                break;
            }
        }

        if ( workbook != null )
        {
            try
            {
                workbook.close();
            }
            catch ( IOException e )
            {}
        }

        if ( excelFile != null )
        {
            try
            {
                excelFile.close();
            }
            catch ( IOException e )
            {}
        }

        return true;
    }

    private static boolean ReadMasterExcelFile()
    {
        FileInputStream excelFile = null;
        Workbook workbook = null;
        Sheet datatypeSheet = null;

        try
        {
            excelFile = new FileInputStream(new File(masterPath));
            workbook = new XSSFWorkbook(excelFile);
            datatypeSheet = workbook.getSheetAt(0);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return false;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return false;
        }

        int row = 2;
    
        alMasterSupplierCode.clear();
        alMasterPartNumber.clear();
        alMasterSupplierName.clear();
        alMasterMPN.clear();
        alMasterLeadTime.clear();
        alMasterUpRev.clear();
        alMasterEOL.clear();
        alMasterLTB.clear();
        alMasterRiskBuy.clear();

        String supplierCode, partNumber, supplierName, mpn, upRev, eol, ltb, riskBuy;
        int leadTime;

        while (true)
        {
            try
            {
                Cell cell = datatypeSheet.getRow(row).getCell(0);
                if (cell.getCellType() == CellType.STRING)
                    supplierCode = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(1);
                if (cell.getCellType() == CellType.STRING)
                    partNumber = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(2);
                if (cell.getCellType() == CellType.STRING)
                    supplierName = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(4);
                
                switch ( cell.getCellType() )
                {
                    case NUMERIC:
                        mpn = "" + Math.round ( cell.getNumericCellValue() );
                        break;

                    case STRING:
                        mpn = "" + Math.round ( cell.getNumericCellValue() );
                        break;

                    default:
                        continue;
                }

                cell = datatypeSheet.getRow(row).getCell(5);
                if (cell.getCellType() == CellType.NUMERIC)
                    leadTime = (int)Math.round(cell.getNumericCellValue());
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(8);
                if (cell.getCellType() == CellType.STRING)
                    upRev = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(9);
                if (cell.getCellType() == CellType.STRING)
                    eol = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(10);
                if (cell.getCellType() == CellType.STRING)
                    ltb = cell.getStringCellValue();
                else
                    continue;

                cell = datatypeSheet.getRow(row).getCell(11);
                if (cell.getCellType() == CellType.STRING)
                    riskBuy = cell.getStringCellValue();
                else
                    continue;

                ++row;
                
                alMasterSupplierCode.add(supplierCode);
                alMasterPartNumber.add(partNumber);
                alMasterSupplierName.add(supplierName);
                alMasterMPN.add(mpn);
                alMasterLeadTime.add(leadTime);
                alMasterUpRev.add(upRev);
                alMasterEOL.add(eol);
                alMasterLTB.add(ltb);
                alMasterRiskBuy.add(riskBuy);
            }
            catch (NullPointerException e)
            {
                break;
            }
        }

        if ( workbook != null )
        {
            try
            {
                workbook.close();
            }
            catch ( IOException e )
            {}
        }

        if ( excelFile != null )
        {
            try
            {
                excelFile.close();
            }
            catch ( IOException e )
            {}
        }

        return true;
    }

    private static boolean WritePlannerSupplierInformation(String plannerSupplierTable)
    {
        Date entryDate, needDate, supplyDate;
        String planner, model, productNumber, supplier;
        int needQuantity, supplyQuantity;

        String sql = "DELETE FROM \"" + plannerSupplierTable + "\"";

        PreparedStatement ps = null;
        
        try
        {
            ps = Database.GetPreparedStatement(sql);

            ps.executeUpdate();
            ps.close();
            ps = null;
            Database.Commit();
        }
        catch ( SQLException e )
        {
            e.printStackTrace();

            if ( ps != null )
            {
                try
                {
                    ps.close();
                }
                catch ( SQLException ex )
                {}
            }

            return false;
        }
        
        sql = "INSERT INTO \"" + plannerSupplierTable + "\" " +
              "(\"Entry Date\",\"Planner\",\"Model\",\"Product Number\",\"Need Date\",\"Need Quantity\",\"Supplier\",\"Supply Date\",\"Supply Quantity\") " +
              "VALUES (?,?,?,?,?,?,?,?,?)";

        for (int itemIndex = 0; itemIndex < alEntryDate.size(); ++itemIndex)
        {
            entryDate = alEntryDate.get(itemIndex);
            planner = alPlanner.get(itemIndex);
            model = alModel.get(itemIndex);
            productNumber = alProductNumber.get(itemIndex);
            needDate = alNeedDate.get(itemIndex);
            needQuantity = alNeedQuantity.get(itemIndex);
            supplier = alSupplier.get(itemIndex);
            supplyDate = alSupplyDate.get(itemIndex);
            supplyQuantity = alSupplyQuantity.get(itemIndex);

            ps = null;
            
            try
            {
                ps = Database.GetPreparedStatement(sql);

                Calendar calendar = Calendar.getInstance();

                calendar.setTime(entryDate);
                ps.setDate(1, new java.sql.Date(calendar.getTime().getTime()));

                ps.setString(2, planner);
                ps.setString(3, model);
                ps.setString(4, productNumber);

                calendar.setTime(needDate);
                ps.setDate(5, new java.sql.Date(calendar.getTime().getTime()));

                ps.setInt(6, needQuantity);
                ps.setString(7, supplier);

                calendar.setTime(supplyDate);
                ps.setDate(8, new java.sql.Date(calendar.getTime().getTime()));

                ps.setInt(9, supplyQuantity);

                ps.executeUpdate();
                ps.close();
                ps = null;
                Database.Commit();
            }
            catch ( SQLException | NumberFormatException e )
            {
                e.printStackTrace();
                
                if ( ps != null )
                {
                    try
                    {
                        ps.close();
                    }
                    catch ( SQLException ex )
                    {}
                }
                
                return false;
            }
        }
        
        return true;
    }

    private static boolean WriteMasterInformation(String masterTable)
    {
        String supplierCode, partNumber, supplierName, mpn, upRev, eol, ltb, riskBuy;
        int leadTime;

        String sql = "DELETE FROM \"" + masterTable + "\"";

        PreparedStatement ps = null;
        
        try
        {
            ps = Database.GetPreparedStatement(sql);

            ps.executeUpdate();
            ps.close();
            ps = null;
            Database.Commit();
        }
        catch ( SQLException e )
        {
            e.printStackTrace();

            if ( ps != null )
            {
                try
                {
                    ps.close();
                }
                catch ( SQLException ex )
                {}
            }

            return false;
        }
        
        sql = "INSERT INTO \"" + masterTable + "\" " +
              "(\"Supplier Code\",\"Part Number\",\"Supplier Name\",\"MPN\",\"Lead Time\",\"UpRev\",\"EOL\",\"LTB\",\"Risk Buy\") " +
              "VALUES (?,?,?,?,?,?,?,?,?)";

        for (int itemIndex = 0; itemIndex < alMasterSupplierCode.size(); ++itemIndex)
        {
            supplierCode = alMasterSupplierCode.get(itemIndex);
            partNumber = alMasterPartNumber.get(itemIndex);
            supplierName = alMasterSupplierName.get(itemIndex);
            mpn = alMasterMPN.get(itemIndex);
            leadTime = alMasterLeadTime.get(itemIndex);
            upRev = alMasterUpRev.get(itemIndex);
            eol = alMasterEOL.get(itemIndex);
            ltb = alMasterLTB.get(itemIndex);
            riskBuy = alMasterRiskBuy.get(itemIndex);

            ps = null;
            
            try
            {
                ps = Database.GetPreparedStatement(sql);
                ps.setString(1, supplierCode);
                ps.setString(2, partNumber);
                ps.setString(3, supplierName);
                ps.setString(4, mpn);
                ps.setInt(5, leadTime);
                ps.setString(6, upRev);
                ps.setString(7, eol);
                ps.setString(8, ltb);
                ps.setString(9, riskBuy);

                ps.executeUpdate();
                ps.close();
                ps = null;
                Database.Commit();
            }
            catch ( SQLException | NumberFormatException e )
            {
                e.printStackTrace();
                
                if ( ps != null )
                {
                    try
                    {
                        ps.close();
                    }
                    catch ( SQLException ex )
                    {}
                }
                
                return false;
            }
        }
        
        return true;
    }

    private static boolean UpdateCurrentWriteTable ( int currentWriteTable )
    {
        String sql = "UPDATE \"Reading Count\" SET \"Current Table\"=?";

        PreparedStatement ps = null;
        
        try
        {
            ps = Database.GetPreparedStatement ( sql );
            ps.setInt ( 1, currentWriteTable );

            ps.executeUpdate();
            ps.close();
            ps = null;
            Database.Commit();
        }
        catch ( SQLException e )
        {
            e.printStackTrace();

            if ( ps != null )
            {
                try
                {
                    ps.close();
                }
                catch ( SQLException ex )
                {}
            }

            return false;
        }
        
        return true;
    }
    
    public static void main(String[] args)
    {
        // TODO code application logic here
        Database.InitDatabase();

        try
        {
            Database.OpenDatabase();
        }
        catch ( SQLException e )
        {
            e.printStackTrace();
            System.exit ( -1 );
        }

        while ( true )
        {
            int currentWriteTable = GetCurrentWriteTable();

            if ( currentWriteTable == 0 )
                break;

            String plannerSupplierTable = "Planner Supplier Information";
            String masterTable = "Master Information";

            if ( currentWriteTable != 1 )
            {
                plannerSupplierTable += " " + currentWriteTable;
                masterTable += " " + currentWriteTable;
            }

            boolean isPlannerSupplierUpdated = false, isMasterUpdated = false;

            if (ReadPlannerSupplierExcelFile())
            {
                if (alEntryDate.size() > 0)
                {
                    if ( WritePlannerSupplierInformation ( plannerSupplierTable ) )
                        isPlannerSupplierUpdated = true;
                }
            }

            if (ReadMasterExcelFile())
            {
                if (alMasterSupplierCode.size() > 0)
                {
                    if ( WriteMasterInformation ( masterTable ) )
                        isMasterUpdated = true;
                }
            }

            if ( isPlannerSupplierUpdated || isMasterUpdated )
                UpdateCurrentWriteTable ( currentWriteTable );

            try
            {
                Thread.sleep ( 2000 );
            }
            catch ( InterruptedException e )
            {}
        }
        
        try
        {
            Database.CloseDatabase();
        }
        catch ( SQLException e )
        {}
    }
}
